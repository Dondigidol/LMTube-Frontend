import React from "react";
import Video from "./Video";
import NoVideoContainer from "../containers/NoVideoContainer";
import { getVideo } from "../../actions/videoActions";
import PropTypes from "prop-types";
import { connect } from "react-redux";

class EmbedVideo extends React.Component {
  componentDidMount() {
    this.props.getVideo(this.props.match.params.videoId);
  }

  render() {
    return (
      <div>{this.props.error.message ? <NoVideoContainer /> : <Video />}</div>
    );
  }
}

EmbedVideo.propTypes = {
  video: PropTypes.object.isRequired,
  getVideo: PropTypes.func.isRequired,
  error: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => {
  return {
    video: state.videos.video,
    error: state.errors,
  };
};

export default connect(mapStateToProps, { getVideo })(EmbedVideo);
